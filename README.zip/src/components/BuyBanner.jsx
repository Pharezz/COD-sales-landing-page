import React from "react";

const BuyBanner = () => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-red-600 text-white text-lg text-center z-1000 p-4 ">
      Click Here to Buy it Now!
    </div>
  );
};

export default BuyBanner;
